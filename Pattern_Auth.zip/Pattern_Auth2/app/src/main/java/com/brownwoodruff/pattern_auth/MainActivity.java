package com.brownwoodruff.pattern_auth;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;


import com.andrognito.patternlockview.PatternLockView;
import com.andrognito.patternlockview.listener.PatternLockViewListener;
import com.andrognito.patternlockview.utils.PatternLockUtils;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    PatternLockView patternLockView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final PatternLockView patternLockView = findViewById(R.id.patternView);

        patternLockView.addPatternLockListener(new PatternLockViewListener() {
            @Override
            public void onStarted() {

            }

            @Override
            public void onProgress(List progressPattern) {

            }

            @Override
            public void onComplete(List pattern) {

              Log.d(getClass().getName(), "PatternComplete:" +
                      PatternLockUtils.patternToString(patternLockView, pattern));
              if(PatternLockUtils.patternToString(patternLockView, pattern).equalsIgnoreCase("123")) {
                  Toast.makeText(MainActivity.this, "Welcome!", Toast.LENGTH_LONG).show();
              }else{
                  Toast.makeText(MainActivity.this, "Incorrect", Toast.LENGTH_LONG).show();
              }

            }

            @Override
            public void onCleared() {

            }
        });
    }
}
